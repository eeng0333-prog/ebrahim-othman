// انتظار تحميل الصفحة بالكامل
document.addEventListener("DOMContentLoaded", () => {
  // طباعة رسالة في وحدة التحكم
  console.log("تم تحميل موقع إبراهيم المخلافي بنجاح")

  // تهيئة شريط التمرير
  initializeCarousel()

  // تهيئة الرسائل المنبثقة
  initializeToasts()
})

// دالة تهيئة شريط التمرير
function initializeCarousel() {
  // الحصول على عنصر شريط التمرير
  const carousel = document.getElementById("heroCarousel")

  // التحقق من وجود العنصر
  if (carousel) {
    // إنشاء كائن Bootstrap Carousel
    const bsCarousel = new window.bootstrap.Carousel(carousel, {
      // فترة التبديل التلقائي (5 ثوان)
      interval: 5000,
      // السماح بالتمرير باللمس
      touch: true,
      // الإيقاف عند التمرير
      pause: "hover",
    })

    // طباعة رسالة نجاح
    console.log("تم تهيئة شريط التمرير بنجاح")
  }
}

// دالة تهيئة الرسائل المنبثقة
function initializeToasts() {
  // إنشاء حاوية الرسائل المنبثقة
  createToastContainer()

  // طباعة رسالة نجاح
  console.log("تم تهيئة نظام الرسائل المنبثقة")
}

// دالة إنشاء حاوية الرسائل المنبثقة
function createToastContainer() {
  // التحقق من عدم وجود الحاوية مسبقاً
  if (!document.getElementById("toast-container")) {
    // إنشاء عنصر div للحاوية
    const container = document.createElement("div")
    // تعيين معرف فريد
    container.id = "toast-container"
    // تعيين الفئات CSS
    container.className = "toast-container position-fixed top-0 end-0 p-3"
    // تعيين z-index عالي
    container.style.zIndex = "9999"
    // إضافة الحاوية إلى الجسم
    document.body.appendChild(container)
  }
}

// دالة عرض رسالة منبثقة
function showToast(message, type = "success") {
  // الحصول على حاوية الرسائل
  const container = document.getElementById("toast-container")

  // تحديد لون الرسالة حسب النوع
  let bgClass = "bg-success"
  let icon = "fas fa-check-circle"

  // تغيير اللون والأيقونة حسب نوع الرسالة
  if (type === "error") {
    bgClass = "bg-danger"
    icon = "fas fa-exclamation-circle"
  } else if (type === "warning") {
    bgClass = "bg-warning"
    icon = "fas fa-exclamation-triangle"
  } else if (type === "info") {
    bgClass = "bg-info"
    icon = "fas fa-info-circle"
  }

  // إنشاء معرف فريد للرسالة
  const toastId = "toast-" + Date.now()

  // إنشاء HTML للرسالة المنبثقة
  const toastHTML = `
        <div id="${toastId}" class="toast ${bgClass} text-white" role="alert">
            <div class="toast-header ${bgClass} text-white border-0">
                <i class="${icon} me-2"></i>
                <strong class="me-auto">إشعار</strong>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="toast"></button>
            </div>
            <div class="toast-body">
                ${message}
            </div>
        </div>
    `

  // إضافة الرسالة إلى الحاوية
  container.insertAdjacentHTML("beforeend", toastHTML)

  // الحصول على عنصر الرسالة المنبثقة
  const toastElement = document.getElementById(toastId)

  // إنشاء كائن Bootstrap Toast
  const toast = new window.bootstrap.Toast(toastElement, {
    // مدة العرض (4 ثوان)
    delay: 4000,
  })

  // عرض الرسالة
  toast.show()

  // إزالة الرسالة من DOM بعد إخفائها
  toastElement.addEventListener("hidden.bs.toast", () => {
    toastElement.remove()
  })
}

// دالة إضافة عنصر إلى السلة
function addToCart(itemName, price) {
  // عرض رسالة نجاح
  showToast(`تم إضافة ${itemName} إلى السلة بنجاح!`, "success")

  // طباعة تفاصيل العنصر في وحدة التحكم
  console.log(`تم إضافة عنصر: ${itemName} - السعر: ${price} ريال`)
}

// دالة تحميل محتوى عبر Ajax
function loadContent(url, targetId) {
  // إنشاء طلب Ajax جديد
  const xhr = new XMLHttpRequest()

  // تعيين دالة معالجة الاستجابة
  xhr.onreadystatechange = () => {
    // التحقق من اكتمال الطلب
    if (xhr.readyState === 4) {
      // التحقق من نجاح الطلب
      if (xhr.status === 200) {
        // إدراج المحتوى في العنصر المحدد
        document.getElementById(targetId).innerHTML = xhr.responseText
        // عرض رسالة نجاح
        showToast("تم تحميل المحتوى بنجاح!", "success")
      } else {
        // عرض رسالة خطأ
        showToast("حدث خطأ في تحميل المحتوى", "error")
        // طباعة الخطأ في وحدة التحكم
        console.error("خطأ في تحميل المحتوى:", xhr.status)
      }
    }
  }

  // فتح الطلب
  xhr.open("GET", url, true)
  // إرسال الطلب
  xhr.send()
}

// دالة التحقق من صحة البريد الإلكتروني
function validateEmail(email) {
  // نمط التحقق من البريد الإلكتروني
  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  // إرجاع نتيجة التحقق
  return emailPattern.test(email)
}

// دالة التحقق من صحة رقم الهاتف
function validatePhone(phone) {
  // نمط التحقق من رقم الهاتف السعودي
  const phonePattern = /^(05|5)[0-9]{8}$/
  // إرجاع نتيجة التحقق
  return phonePattern.test(phone)
}
