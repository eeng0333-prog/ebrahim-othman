// انتظار تحميل الصفحة بالكامل
document.addEventListener("DOMContentLoaded", () => {
  // طباعة رسالة في وحدة التحكم
  console.log("تم تحميل صفحة المنتجات بنجاح")

  // تهيئة نظام التصفية
  initializeFilters()

  // تهيئة البحث
  initializeSearch()

  // تهيئة قائمة الترتيب
  createSortDropdown()
})

// دالة تهيئة نظام التصفية
function initializeFilters() {
  // الحصول على جميع أزرار التصفية
  const filterButtons = document.querySelectorAll(".filter-btn")

  // إضافة مستمع حدث لكل زر
  filterButtons.forEach((button) => {
    button.addEventListener("click", function () {
      // إزالة الفئة النشطة من جميع الأزرار
      filterButtons.forEach((btn) => btn.classList.remove("active"))

      // إضافة الفئة النشطة للزر المضغوط
      this.classList.add("active")

      // الحصول على فئة التصفية
      const filterValue = this.getAttribute("data-filter")

      // تطبيق التصفية
      filterProducts(filterValue)

      // طباعة رسالة في وحدة التحكم
      console.log(`تم تطبيق تصفية: ${filterValue}`)
    })
  })

  // طباعة رسالة نجاح
  console.log("تم تهيئة نظام التصفية بنجاح")
}

// دالة تصفية المنتجات
function filterProducts(category) {
  // الحصول على جميع بطاقات المنتجات
  const productCards = document.querySelectorAll(".product-card")

  // عداد المنتجات المعروضة
  let visibleCount = 0

  // تكرار عبر جميع البطاقات
  productCards.forEach((card) => {
    // الحصول على فئة المنتج
    const productCategory = card.getAttribute("data-category")

    // التحقق من التطابق مع التصفية
    if (category === "all" || productCategory === category) {
      // إظهار البطاقة
      card.classList.remove("hidden")
      card.style.display = "block"
      visibleCount++
    } else {
      // إخفاء البطاقة
      card.classList.add("hidden")
      card.style.display = "none"
    }
  })

  // عرض رسالة عدد المنتجات
  showToast(`تم العثور على ${visibleCount} منتج`, "info")

  // طباعة النتيجة في وحدة التحكم
  console.log(`تم عرض ${visibleCount} منتج من فئة ${category}`)
}

// دالة تهيئة البحث
function initializeSearch() {
  // إنشاء حقل البحث
  createSearchField()

  // طباعة رسالة نجاح
  console.log("تم تهيئة نظام البحث بنجاح")
}

// دالة إنشاء حقل البحث
function createSearchField() {
  // الحصول على قسم التصفية
  const filterSection = document.querySelector(".filter-section")

  // إنشاء حاوية البحث
  const searchContainer = document.createElement("div")
  searchContainer.className = "search-container mt-3 d-flex justify-content-center"

  // إنشاء حقل البحث
  const searchInput = document.createElement("input")
  searchInput.type = "text"
  searchInput.className = "form-control"
  searchInput.placeholder = "ابحث عن منتج..."
  searchInput.style.maxWidth = "300px"
  searchInput.id = "productSearch"

  // إضافة مستمع حدث للبحث
  searchInput.addEventListener("input", function () {
    // الحصول على نص البحث
    const searchTerm = this.value.toLowerCase().trim()

    // تطبيق البحث
    searchProducts(searchTerm)
  })

  // إضافة حقل البحث إلى الحاوية
  searchContainer.appendChild(searchInput)

  // إضافة الحاوية إلى قسم التصفية
  filterSection.appendChild(searchContainer)
}

// دالة البحث في المنتجات
function searchProducts(searchTerm) {
  // الحصول على جميع بطاقات المنتجات
  const productCards = document.querySelectorAll(".product-card")

  // عداد النتائج
  let resultsCount = 0

  // تكرار عبر جميع البطاقات
  productCards.forEach((card) => {
    // الحصول على اسم المنتج
    const productTitle = card.querySelector(".product-title").textContent.toLowerCase()

    // الحصول على وصف المنتج
    const productDescription = card.querySelector(".product-description").textContent.toLowerCase()

    // التحقق من وجود نص البحث
    if (searchTerm === "" || productTitle.includes(searchTerm) || productDescription.includes(searchTerm)) {
      // إظهار البطاقة
      card.style.display = "block"
      card.classList.remove("hidden")
      resultsCount++
    } else {
      // إخفاء البطاقة
      card.style.display = "none"
      card.classList.add("hidden")
    }
  })

  // عرض رسالة النتائج إذا كان هناك بحث
  if (searchTerm !== "") {
    showToast(`تم العثور على ${resultsCount} نتيجة للبحث: "${searchTerm}"`, "info")
  }

  // طباعة النتيجة في وحدة التحكم
  console.log(`نتائج البحث عن "${searchTerm}": ${resultsCount} منتج`)
}

// دالة إضافة منتج إلى السلة مع تأثيرات بصرية
function addToCartWithAnimation(productName, price, buttonElement) {
  // تغيير نص الزر مؤقتاً
  const originalText = buttonElement.innerHTML
  buttonElement.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i> جاري الإضافة...'
  buttonElement.disabled = true

  // محاكاة تأخير الإضافة
  setTimeout(() => {
    // استدعاء دالة الإضافة الأصلية
    addToCart(productName, price)

    // إعادة النص الأصلي
    buttonElement.innerHTML = '<i class="fas fa-check me-1"></i> تم الإضافة!'
    buttonElement.classList.add("btn-success")
    buttonElement.classList.remove("btn-primary")

    // إعادة الزر لحالته الأصلية بعد ثانيتين
    setTimeout(() => {
      buttonElement.innerHTML = originalText
      buttonElement.classList.remove("btn-success")
      buttonElement.classList.add("btn-primary")
      buttonElement.disabled = false
    }, 2000)
  }, 1000)

  // طباعة رسالة في وحدة التحكم
  console.log(`تم بدء عملية إضافة ${productName} إلى السلة`)
}

// دالة ترتيب المنتجات
function sortProducts(sortBy) {
  // الحصول على حاوية المنتجات
  const productsGrid = document.getElementById("productsGrid")

  // الحصول على جميع بطاقات المنتجات
  const productCards = Array.from(productsGrid.querySelectorAll(".product-card"))

  // ترتيب البطاقات حسب المعيار
  productCards.sort((a, b) => {
    if (sortBy === "price-low") {
      // ترتيب حسب السعر من الأقل للأعلى
      const priceA = Number.parseFloat(a.querySelector(".product-price").textContent.replace(/[^\d.]/g, ""))
      const priceB = Number.parseFloat(b.querySelector(".product-price").textContent.replace(/[^\d.]/g, ""))
      return priceA - priceB
    } else if (sortBy === "price-high") {
      // ترتيب حسب السعر من الأعلى للأقل
      const priceA = Number.parseFloat(a.querySelector(".product-price").textContent.replace(/[^\d.]/g, ""))
      const priceB = Number.parseFloat(b.querySelector(".product-price").textContent.replace(/[^\d.]/g, ""))
      return priceB - priceA
    } else if (sortBy === "name") {
      // ترتيب حسب الاسم أبجدياً
      const nameA = a.querySelector(".product-title").textContent
      const nameB = b.querySelector(".product-title").textContent
      return nameA.localeCompare(nameB, "ar")
    } else if (sortBy === "rating") {
      // ترتيب حسب التقييم
      const ratingA = Number.parseFloat(a.querySelector(".rating-text").textContent.replace(/[()]/g, ""))
      const ratingB = Number.parseFloat(b.querySelector(".rating-text").textContent.replace(/[()]/g, ""))
      return ratingB - ratingA
    }
    return 0
  })

  // إعادة ترتيب العناصر في DOM
  productCards.forEach((card) => {
    productsGrid.appendChild(card)
  })

  // عرض رسالة نجاح
  showToast(`تم ترتيب المنتجات حسب ${getSortDisplayName(sortBy)}`, "success")

  // طباعة رسالة في وحدة التحكم
  console.log(`تم ترتيب المنتجات حسب: ${sortBy}`)
}

// دالة الحصول على اسم الترتيب للعرض
function getSortDisplayName(sortBy) {
  const sortNames = {
    "price-low": "السعر (من الأقل للأعلى)",
    "price-high": "السعر (من الأعلى للأقل)",
    name: "الاسم (أبجدياً)",
    rating: "التقييم (من الأعلى للأقل)",
  }
  return sortNames[sortBy] || sortBy
}

// دالة إنشاء قائمة الترتيب
function createSortDropdown() {
  // الحصول على قسم التصفية
  const filterSection = document.querySelector(".filter-section")

  // إنشاء حاوية الترتيب
  const sortContainer = document.createElement("div")
  sortContainer.className = "sort-container mt-3 d-flex justify-content-center"

  // إنشاء قائمة الترتيب
  const sortSelect = document.createElement("select")
  sortSelect.className = "form-select"
  sortSelect.style.maxWidth = "250px"
  sortSelect.id = "sortSelect"

  // إضافة خيارات الترتيب
  const sortOptions = [
    { value: "", text: "ترتيب حسب..." },
    { value: "name", text: "الاسم (أبجدياً)" },
    { value: "price-low", text: "السعر (من الأقل للأعلى)" },
    { value: "price-high", text: "السعر (من الأعلى للأقل)" },
    { value: "rating", text: "التقييم (من الأعلى للأقل)" },
  ]

  // إضافة الخيارات إلى القائمة
  sortOptions.forEach((option) => {
    const optionElement = document.createElement("option")
    optionElement.value = option.value
    optionElement.textContent = option.text
    sortSelect.appendChild(optionElement)
  })

  // إضافة مستمع حدث للترتيب
  sortSelect.addEventListener("change", function () {
    if (this.value) {
      sortProducts(this.value)
    }
  })

  // إضافة القائمة إلى الحاوية
  sortContainer.appendChild(sortSelect)

  // إضافة الحاوية إلى قسم التصفية
  filterSection.appendChild(sortContainer)
}

// دالة عرض رسالة نجاح
function showToast(message, type) {
  // هنا يمكن إضافة الكود لعرض الرسالة بنجاح
  console.log(`[${type}] ${message}`)
}

// دالة إضافة منتج إلى السلة
function addToCart(productName, price) {
  // هنا يمكن إضافة الكود لإضافة المنتج إلى السلة
  console.log(`تم إضافة ${productName} بسعر ${price} إلى السلة`)
}
