"use client"

import  from "../js/menu"

export default function SyntheticV0PageForDeployment() {
  return < />
}